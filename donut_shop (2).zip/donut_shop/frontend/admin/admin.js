// Configuração da API
const API_BASE_URL = 'http://localhost:3001';

// Estado da aplicação
let usuarioLogado = null;
let crudAtual = '';
let itemEditando = null;

// Elementos do DOM
const nomeUsuario = document.getElementById('nomeUsuario');
const btnLogout = document.getElementById('btnLogout');
const crudModal = document.getElementById('crudModal');
const formModal = document.getElementById('formModal');
const modalOverlay = document.getElementById('modalOverlay');
const formOverlay = document.getElementById('formOverlay');
const modalTitle = document.getElementById('modalTitle');
const formTitle = document.getElementById('formTitle');
const dataTable = document.getElementById('dataTable');
const tableHead = document.getElementById('tableHead');
const tableBody = document.getElementById('tableBody');
const itemForm = document.getElementById('itemForm');
const formFields = document.getElementById('formFields');

// Configurações dos CRUDs
const crudConfigs = {
    categorias: {
        title: 'Categorias',
        endpoint: '/categorias',
        fields: [
            { name: 'id_categoria', label: 'ID', type: 'number', readonly: true },
            { name: 'nome_categoria', label: 'Nome', type: 'text', required: true },
            { name: 'descricao_categoria', label: 'Descrição', type: 'textarea' }
        ],
        columns: ['ID', 'Nome', 'Descrição', 'Ações']
    },
    produtos: {
        title: 'Produtos',
        endpoint: '/donuts',
        fields: [
            { name: 'id_produto', label: 'ID', type: 'number', readonly: true },
            { name: 'nome_produto', label: 'Nome', type: 'text', required: true },
            { name: 'descricao_produto', label: 'Descrição', type: 'textarea' },
            { name: 'preco_produto', label: 'Preço', type: 'number', step: '0.01', required: true },
            { name: 'quantidade_estoque', label: 'Estoque', type: 'number', required: true },
            { name: 'categoria_id', label: 'Categoria', type: 'select', required: true, options: [] },
            { name: 'imagem_produto', label: 'URL da Imagem', type: 'text' }
        ],
        columns: ['ID', 'Nome', 'Descrição', 'Preço', 'Estoque', 'Categoria', 'Ações']
    },
    usuarios: {
        title: 'Usuários',
        endpoint: '/usuarios',
        fields: [
            { name: 'id_usuario', label: 'ID', type: 'number', readonly: true },
            { name: 'nome_usuario', label: 'Nome', type: 'text', required: true },
            { name: 'email_usuario', label: 'Email', type: 'email', required: true },
            { name: 'ativo', label: 'Ativo', type: 'checkbox' }
        ],
        columns: ['ID', 'Nome', 'Email', 'Data Cadastro', 'Ativo', 'Ações']
    },
    pedidos: {
        title: 'Pedidos',
        endpoint: '/pedidos',
        fields: [
            { name: 'id_pedido', label: 'ID', type: 'number', readonly: true },
            { name: 'usuario_id', label: 'Usuário', type: 'select', required: true, options: [] },
            { name: 'status_pedido', label: 'Status', type: 'select', required: true, options: [
                { value: 'pendente', text: 'Pendente' },
                { value: 'processando', text: 'Processando' },
                { value: 'enviado', text: 'Enviado' },
                { value: 'entregue', text: 'Entregue' },
                { value: 'cancelado', text: 'Cancelado' }
            ]},
            { name: 'valor_total', label: 'Valor Total', type: 'number', step: '0.01', readonly: true },
            { name: 'observacoes', label: 'Observações', type: 'textarea' }
        ],
        columns: ['ID', 'Usuário', 'Data', 'Status', 'Valor Total', 'Ações']
    },
    enderecos: {
        title: 'Endereços',
        endpoint: '/enderecos',
        fields: [
            { name: 'id_endereco', label: 'ID', type: 'number', readonly: true },
            { name: 'usuario_id', label: 'Usuário', type: 'select', required: true, options: [] },
            { name: 'rua', label: 'Rua', type: 'text', required: true },
            { name: 'numero', label: 'Número', type: 'text', required: true },
            { name: 'complemento', label: 'Complemento', type: 'text' },
            { name: 'bairro', label: 'Bairro', type: 'text', required: true },
            { name: 'cidade', label: 'Cidade', type: 'text', required: true },
            { name: 'estado', label: 'Estado', type: 'text', required: true },
            { name: 'cep', label: 'CEP', type: 'text', required: true }
        ],
        columns: ['ID', 'Usuário', 'Endereço Completo', 'Cidade', 'Estado', 'CEP', 'Ações']
    },
    'formas-pagamento': {
        title: 'Formas de Pagamento',
        endpoint: '/forma_pagamento',
        fields: [
            { name: 'id_forma_pagamento', label: 'ID', type: 'number', readonly: true },
            { name: 'nome_forma_pagamento', label: 'Nome', type: 'text', required: true },
            { name: 'ativo', label: 'Ativo', type: 'checkbox' }
        ],
        columns: ['ID', 'Nome', 'Ativo', 'Ações']
    }
};

// Inicialização
document.addEventListener('DOMContentLoaded', async () => {
    await verificarLogin();
    configurarEventListeners();
});

// Verificar se o usuário está logado
async function verificarLogin() {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/verificar`, {
            credentials: 'include'
        });
        
        if (response.ok) {
            const data = await response.json();
            if (data.logado) {
                usuarioLogado = data.usuario;
                nomeUsuario.textContent = `${data.usuario.nome_usuario}`;
            } else {
                window.location.href = '../auth/login.html';
            }
        } else {
            window.location.href = '../auth/login.html';
        }
    } catch (error) {
        console.error('Erro ao verificar login:', error);
        window.location.href = '../auth/login.html';
    }
}

// Configurar event listeners
function configurarEventListeners() {
    btnLogout.addEventListener('click', logout);
    itemForm.addEventListener('submit', salvarItem);
}

// Abrir CRUD
function abrirCrud(crud) {
    crudAtual = crud;
    const config = crudConfigs[crud];
    
    if (!config) {
        alert('CRUD não encontrado!');
        return;
    }
    
    modalTitle.textContent = config.title;
    
    // Configurar cabeçalho da tabela
    tableHead.innerHTML = '';
    const headerRow = document.createElement('tr');
    config.columns.forEach(column => {
        const th = document.createElement('th');
        th.textContent = column;
        headerRow.appendChild(th);
    });
    tableHead.appendChild(headerRow);
    
    // Carregar dados
    carregarItens();
    
    // Mostrar modal
    crudModal.classList.add('show');
    modalOverlay.classList.add('show');
}

// Carregar itens
async function carregarItens() {
    const config = crudConfigs[crudAtual];
    tableBody.innerHTML = '<tr><td colspan="100%" class="loading">Carregando...</td></tr>';
    
    try {
        const response = await fetch(`${API_BASE_URL}${config.endpoint}`, {
            credentials: 'include'
        });
        
        if (response.ok) {
            const data = await response.json();
            renderizarTabela(data);
        } else {
            tableBody.innerHTML = '<tr><td colspan="100%" class="empty-state">Erro ao carregar dados</td></tr>';
        }
    } catch (error) {
        console.error('Erro ao carregar itens:', error);
        tableBody.innerHTML = '<tr><td colspan="100%" class="empty-state">Erro de conexão</td></tr>';
    }
}

// Renderizar tabela
function renderizarTabela(data) {
    tableBody.innerHTML = '';
    
    if (data.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="100%" class="empty-state">Nenhum item encontrado</td></tr>';
        return;
    }
    
    data.forEach(item => {
        const row = document.createElement('tr');
        
        // Renderizar colunas baseado no tipo de CRUD
        switch (crudAtual) {
            case 'categorias':
                row.innerHTML = `
                    <td>${item.id_categoria}</td>
                    <td>${item.nome_categoria}</td>
                    <td>${item.descricao_categoria || '-'}</td>
                    <td>
                        <button class="btn-edit" onclick="editarItem(${item.id_categoria})">Editar</button>
                        <button class="btn-danger" onclick="deletarItem(${item.id_categoria})">Excluir</button>
                    </td>
                `;
                break;
            case 'produtos':
                row.innerHTML = `
                    <td>${item.id_produto}</td>
                    <td>${item.nome_produto}</td>
                    <td>${item.descricao_produto || '-'}</td>
                    <td>R$ ${parseFloat(item.preco_produto).toFixed(2).replace('.', ',')}</td>
                    <td>${item.quantidade_estoque}</td>
                    <td>${item.nome_categoria || '-'}</td>
                    <td>
                        <button class="btn-edit" onclick="editarItem(${item.id_produto})">Editar</button>
                        <button class="btn-danger" onclick="deletarItem(${item.id_produto})">Excluir</button>
                    </td>
                `;
                break;
            case 'usuarios':
                row.innerHTML = `
                    <td>${item.id_usuario}</td>
                    <td>${item.nome_usuario}</td>
                    <td>${item.email_usuario}</td>
                    <td>${new Date(item.data_cadastro).toLocaleDateString('pt-BR')}</td>
                    <td>${item.ativo ? 'Sim' : 'Não'}</td>
                    <td>
                        <button class="btn-edit" onclick="editarItem(${item.id_usuario})">Editar</button>
                        <button class="btn-danger" onclick="deletarItem(${item.id_usuario})">Excluir</button>
                    </td>
                `;
                break;
            case 'pedidos':
                row.innerHTML = `
                    <td>${item.id_pedido}</td>
                    <td>${item.nome_usuario || '-'}</td>
                    <td>${new Date(item.data_pedido).toLocaleDateString('pt-BR')}</td>
                    <td>${item.status_pedido}</td>
                    <td>R$ ${parseFloat(item.valor_total || 0).toFixed(2).replace('.', ',')}</td>
                    <td>
                        <button class="btn-edit" onclick="editarItem(${item.id_pedido})">Editar</button>
                        <button class="btn-danger" onclick="deletarItem(${item.id_pedido})">Excluir</button>
                    </td>
                `;
                break;
            default:
                // Renderização genérica
                const keys = Object.keys(item);
                keys.slice(0, -1).forEach(key => {
                    const td = document.createElement('td');
                    td.textContent = item[key] || '-';
                    row.appendChild(td);
                });
                
                const actionTd = document.createElement('td');
                actionTd.innerHTML = `
                    <button class="btn-edit" onclick="editarItem(${item[keys[0]]})">Editar</button>
                    <button class="btn-danger" onclick="deletarItem(${item[keys[0]]})">Excluir</button>
                `;
                row.appendChild(actionTd);
        }
        
        tableBody.appendChild(row);
    });
}

// Novo item
function novoItem() {
    itemEditando = null;
    formTitle.textContent = `Novo ${crudConfigs[crudAtual].title.slice(0, -1)}`;
    criarFormulario();
    formModal.classList.add('show');
    formOverlay.classList.add('show');
}

// Editar item
async function editarItem(id) {
    const config = crudConfigs[crudAtual];
    
    try {
        const response = await fetch(`${API_BASE_URL}${config.endpoint}/${id}`, {
            credentials: 'include'
        });
        
        if (response.ok) {
            itemEditando = await response.json();
            formTitle.textContent = `Editar ${config.title.slice(0, -1)}`;
            criarFormulario(itemEditando);
            formModal.classList.add('show');
            formOverlay.classList.add('show');
        } else {
            alert('Erro ao carregar item para edição');
        }
    } catch (error) {
        console.error('Erro ao editar item:', error);
        alert('Erro de conexão');
    }
}

// Deletar item
async function deletarItem(id) {
    if (!confirm('Tem certeza que deseja excluir este item?')) {
        return;
    }
    
    const config = crudConfigs[crudAtual];
    
    try {
        const response = await fetch(`${API_BASE_URL}${config.endpoint}/${id}`, {
            method: 'DELETE',
            credentials: 'include'
        });
        
        if (response.ok) {
            alert('Item excluído com sucesso!');
            carregarItens();
        } else {
            const error = await response.json();
            alert('Erro ao excluir item: ' + (error.error || 'Erro desconhecido'));
        }
    } catch (error) {
        console.error('Erro ao deletar item:', error);
        alert('Erro de conexão');
    }
}

// Criar formulário
function criarFormulario(data = null) {
    const config = crudConfigs[crudAtual];
    formFields.innerHTML = '';
    
    config.fields.forEach(field => {
        const formGroup = document.createElement('div');
        formGroup.className = 'form-group';
        
        const label = document.createElement('label');
        label.textContent = field.label;
        label.setAttribute('for', field.name);
        formGroup.appendChild(label);
        
        let input;
        
        switch (field.type) {
            case 'textarea':
                input = document.createElement('textarea');
                break;
            case 'select':
                input = document.createElement('select');
                if (field.options) {
                    field.options.forEach(option => {
                        const optionElement = document.createElement('option');
                        optionElement.value = option.value;
                        optionElement.textContent = option.text;
                        input.appendChild(optionElement);
                    });
                }
                break;
            case 'checkbox':
                input = document.createElement('input');
                input.type = 'checkbox';
                break;
            default:
                input = document.createElement('input');
                input.type = field.type;
                if (field.step) input.step = field.step;
        }
        
        input.id = field.name;
        input.name = field.name;
        
        if (field.required) input.required = true;
        if (field.readonly) input.readOnly = true;
        
        // Preencher valor se estiver editando
        if (data && data[field.name] !== undefined) {
            if (field.type === 'checkbox') {
                input.checked = data[field.name];
            } else {
                input.value = data[field.name];
            }
        }
        
        formGroup.appendChild(input);
        formFields.appendChild(formGroup);
    });
}

// Salvar item
async function salvarItem(e) {
    e.preventDefault();
    
    const config = crudConfigs[crudAtual];
    const formData = new FormData(itemForm);
    const data = {};
    
    // Converter FormData para objeto
    for (let [key, value] of formData.entries()) {
        const field = config.fields.find(f => f.name === key);
        if (field) {
            if (field.type === 'checkbox') {
                data[key] = document.getElementById(key).checked;
            } else if (field.type === 'number') {
                data[key] = value ? parseFloat(value) : null;
            } else {
                data[key] = value || null;
            }
        }
    }
    
    // Adicionar campos checkbox não marcados
    config.fields.forEach(field => {
        if (field.type === 'checkbox' && !formData.has(field.name)) {
            data[field.name] = false;
        }
    });
    
    try {
        let response;
        
        if (itemEditando) {
            // Atualizar
            const id = itemEditando[config.fields[0].name];
            response = await fetch(`${API_BASE_URL}${config.endpoint}/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include',
                body: JSON.stringify(data)
            });
        } else {
            // Criar
            response = await fetch(`${API_BASE_URL}${config.endpoint}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include',
                body: JSON.stringify(data)
            });
        }
        
        if (response.ok) {
            alert('Item salvo com sucesso!');
            fecharFormModal();
            carregarItens();
        } else {
            const error = await response.json();
            alert('Erro ao salvar item: ' + (error.error || 'Erro desconhecido'));
        }
    } catch (error) {
        console.error('Erro ao salvar item:', error);
        alert('Erro de conexão');
    }
}

// Fechar modais
function fecharModal() {
    crudModal.classList.remove('show');
    modalOverlay.classList.remove('show');
}

function fecharFormModal() {
    formModal.classList.remove('show');
    formOverlay.classList.remove('show');
    itemEditando = null;
}

// Logout
async function logout() {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/logout`, {
            method: 'POST',
            credentials: 'include'
        });
        
        if (response.ok) {
            window.location.href = '../auth/login.html';
        }
    } catch (error) {
        console.error('Erro no logout:', error);
        window.location.href = '../auth/login.html';
    }
}

