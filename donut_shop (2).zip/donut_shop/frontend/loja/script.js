// Configuração da API
const API_BASE_URL = 'http://localhost:3001';

// Estado da aplicação
let produtos = [];
let carrinho = [];
let usuarioLogado = null;

// Elementos do DOM
const productGrid = document.getElementById('productGrid');
const cartSidebar = document.getElementById('cartSidebar');
const cartOverlay = document.getElementById('cartOverlay');
const cartItems = document.getElementById('cartItems');
const cartCount = document.getElementById('cartCount');
const cartTotal = document.getElementById('cartTotal');
const nomeUsuario = document.getElementById('nomeUsuario');
const btnLogout = document.getElementById('btnLogout');
const btnFinalizarPedido = document.getElementById('btnFinalizarPedido');
const modal = document.getElementById('modalConfirmacao');
const modalOverlay = document.getElementById('modalOverlay');

// Inicialização
document.addEventListener('DOMContentLoaded', async () => {
    configurarEventListeners();
    await carregarProdutos();
    await verificarLogin();
    carregarCarrinhoLocalStorage();
});

// Verificar se o usuário está logado
async function verificarLogin() {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/verificar`, {
            credentials: 'include'
        });

        // tenta ler JSON mesmo se status não for 200 (por segurança)
        let data = {};
        try { data = await response.json(); } catch (_) { data = {}; }

        // aceita tanto "logged" quanto "logado" (robustez)
        const isLogged = data.logged ?? data.logado ?? false;

        // tenta extrair nome e id em vários formatos possíveis
        const nome = data.nome ?? data.nome_usuario ?? (data.usuario && (data.usuario.nome_usuario || data.usuario.nome)) ?? null;
        const id = data.id ?? data.id_usuario ?? (data.usuario && (data.usuario.id_usuario || data.usuario.id)) ?? null;

        if (isLogged) {
            usuarioLogado = { id_usuario: id, nome_usuario: nome };
            nomeUsuario.textContent = `Bem-vindo, ${nome || 'Usuário'}!`;
            document.getElementById('authButtons').style.display = 'none';
            document.getElementById('userInfo').style.display = 'flex';
        } else {
            usuarioLogado = null;
            nomeUsuario.textContent = 'Visitante';
            document.getElementById('authButtons').style.display = 'flex';
            document.getElementById('userInfo').style.display = 'none';
        }

        // atualiza visibilidade do botão de finalizar conforme estado e itens no carrinho
        atualizarCarrinho();
    } catch (error) {
        console.error('Erro ao verificar login:', error);
    }
}

// Carregar produtos da API
async function carregarProdutos() {
    try {
        const response = await fetch(`${API_BASE_URL}/donuts`);
        if (response.ok) {
            produtos = await response.json();
            renderizarProdutos(produtos);
        } else {
            console.error('Erro ao carregar produtos');
            usarProdutosExemplo();
        }
    } catch (error) {
        console.error('Erro ao carregar produtos:', error);
        usarProdutosExemplo();
    }
}

// Produtos de exemplo (fallback)
function usarProdutosExemplo() {
    produtos = [
        { id_produto:1, nome_produto:'Donut Glazed', descricao_produto:'Donut clássico', preco_produto:4.50, categoria_id:1 },
        { id_produto:2, nome_produto:'Donut Chocolate', descricao_produto:'Cobertura de chocolate', preco_produto:5.00, categoria_id:1 },
        { id_produto:3, nome_produto:'Donut Morango', descricao_produto:'Cobertura de morango', preco_produto:5.50, categoria_id:1 }
    ];
    renderizarProdutos(produtos);
}

// Renderizar produtos na tela
function renderizarProdutos(produtosParaRenderizar) {
    productGrid.innerHTML = '';
    
    produtosParaRenderizar.forEach(produto => {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        productCard.innerHTML = `
            <div class="product-image">🍩</div>
            <div class="product-info">
                <h3 class="product-name">${produto.nome_produto}</h3>
                <p class="product-description">${produto.descricao_produto || ''}</p>
                <div class="product-price">R$ ${produto.preco_produto.toFixed(2).replace('.', ',')}</div>
                <div class="product-actions">
                    <div class="quantity-controls">
                        <button class="quantity-btn" onclick="alterarQuantidade(${produto.id_produto}, -1)">-</button>
                        <input type="number" class="quantity-input" id="qty-${produto.id_produto}" value="1" min="1" max="10">
                        <button class="quantity-btn" onclick="alterarQuantidade(${produto.id_produto}, 1)">+</button>
                    </div>
                    <button class="btn-add-cart" data-prod="${produto.id_produto}" onclick="adicionarAoCarrinho(event, ${produto.id_produto})">
                        Adicionar
                    </button>
                </div>
            </div>
        `;
        productGrid.appendChild(productCard);
    });
}

// Configurar event listeners
function configurarEventListeners() {
    // Filtros de categoria
    document.addEventListener('click', (e) => {
        if (e.target && e.target.classList.contains('filter-btn')) {
            const filterButtons = document.querySelectorAll('.filter-btn');
            filterButtons.forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            filtrarProdutos(e.target.dataset.categoria);
        }
    });

    // Logout (btnLogout pode estar escondido, mas existe no DOM)
    if (btnLogout) btnLogout.addEventListener('click', logout);
}

// Filtrar produtos por categoria
function filtrarProdutos(categoria) {
    if (categoria === 'todos') {
        renderizarProdutos(produtos);
    } else {
        const produtosFiltrados = produtos.filter(p => p.categoria_id == categoria);
        renderizarProdutos(produtosFiltrados);
    }
}

// Alterar quantidade do produto
function alterarQuantidade(produtoId, delta) {
    const input = document.getElementById(`qty-${produtoId}`);
    if (!input) return;
    let quantidade = parseInt(input.value) + delta;
    if (isNaN(quantidade)) quantidade = 1;
    if (quantidade < 1) quantidade = 1;
    if (quantidade > 10) quantidade = 10;
    input.value = quantidade;
}

// Adicionar produto ao carrinho
function adicionarAoCarrinho(ev, produtoId) {
    // ev pode ser undefined em alguns cenários; aceitável
    const produto = produtos.find(p => p.id_produto === produtoId);
    const quantidadeInput = document.getElementById(`qty-${produtoId}`);
    const quantidade = parseInt(quantidadeInput?.value || '1');

    if (!produto) return;

    const itemExistente = carrinho.find(item => item.id_produto === produtoId);

    if (itemExistente) {
        itemExistente.quantidade += quantidade;
    } else {
        carrinho.push({
            id_produto: produto.id_produto,
            nome_produto: produto.nome_produto,
            preco_produto: produto.preco_produto,
            quantidade: quantidade
        });
    }

    atualizarCarrinho();
    salvarCarrinhoLocalStorage();

    // Feedback visual no botão (procura pelo atributo data-prod)
    const btn = document.querySelector(`.btn-add-cart[data-prod="${produtoId}"]`);
    if (btn) {
        const textoOriginal = btn.textContent;
        btn.textContent = 'Adicionado!';
        btn.disabled = true;
        setTimeout(() => {
            btn.textContent = textoOriginal;
            btn.disabled = false;
        }, 900);
    }
}

// Atualizar exibição do carrinho
function atualizarCarrinho() {
    // Atualizar contador
    const totalItens = carrinho.reduce((total, item) => total + item.quantidade, 0);
    cartCount.textContent = totalItens;

    // Atualizar itens do carrinho
    cartItems.innerHTML = '';

    if (carrinho.length === 0) {
        cartItems.innerHTML = `
            <div class="empty-cart">
                <p>Seu carrinho está vazio</p>
                <p>Adicione alguns donuts deliciosos!</p>
            </div>
        `;
        btnFinalizarPedido.style.display = 'none';
        btnFinalizarPedido.disabled = true;
    } else {
        carrinho.forEach(item => {
            const cartItem = document.createElement('div');
            cartItem.className = 'cart-item';
            cartItem.innerHTML = `
                <div class="cart-item-info">
                    <div class="cart-item-name">${item.nome_produto}</div>
                    <div class="cart-item-price">R$ ${item.preco_produto.toFixed(2).replace('.', ',')}</div>
                    <div class="cart-item-quantity">
                        <button class="cart-quantity-btn" onclick="alterarQuantidadeCarrinho(${item.id_produto}, -1)">-</button>
                        <span class="cart-quantity-display">${item.quantidade}</span>
                        <button class="cart-quantity-btn" onclick="alterarQuantidadeCarrinho(${item.id_produto}, 1)">+</button>
                        <button class="cart-quantity-btn" onclick="removerDoCarrinho(${item.id_produto})" style="background: #e74c3c; margin-left: 10px;">🗑️</button>
                    </div>
                </div>
            `;
            cartItems.appendChild(cartItem);
        });

        // se usuário logado, mostra botão de pagamento; se não, mantém oculto (conforme sua regra)
        if (usuarioLogado) {
            btnFinalizarPedido.style.display = 'block';
            btnFinalizarPedido.disabled = false;
        } else {
            btnFinalizarPedido.style.display = 'none';
            btnFinalizarPedido.disabled = true;
        }
    }

    // Atualizar total
    const total = carrinho.reduce((total, item) => total + (item.preco_produto * item.quantidade), 0);
    cartTotal.textContent = total.toFixed(2).replace('.', ',');
}

// Alterar quantidade no carrinho
function alterarQuantidadeCarrinho(produtoId, delta) {
    const item = carrinho.find(item => item.id_produto === produtoId);
    if (!item) return;

    item.quantidade += delta;

    if (item.quantidade <= 0) {
        removerDoCarrinho(produtoId);
    } else {
        atualizarCarrinho();
        salvarCarrinhoLocalStorage();
    }
}

// Remover item do carrinho
function removerDoCarrinho(produtoId) {
    carrinho = carrinho.filter(item => item.id_produto !== produtoId);
    atualizarCarrinho();
    salvarCarrinhoLocalStorage();
}

// Toggle do carrinho lateral
function toggleCarrinho() {
    cartSidebar.classList.toggle('open');
    cartOverlay.classList.toggle('show');
}

// Finalizar pedido
async function finalizarPedido() {
    if (!usuarioLogado) {
        alert("Você precisa fazer login para finalizar o pedido.");
        window.location.href = "../auth/login.html";
        return;
    }

    if (carrinho.length === 0) return;

    btnFinalizarPedido.textContent = 'Processando...';
    btnFinalizarPedido.disabled = true;

    try {
        const itens = carrinho.map(item => ({
            produto_id: item.id_produto,
            quantidade: item.quantidade
        }));

        const response = await fetch(`${API_BASE_URL}/pedidos`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({
                usuario_id: usuarioLogado.id_usuario,
                itens: itens,
                observacoes: ''
            })
        });

        if (response.ok) {
            // Pedido realizado com sucesso
            carrinho = [];
            atualizarCarrinho();
            salvarCarrinhoLocalStorage();
            toggleCarrinho();
            mostrarModal();
        } else {
            const error = await response.json();
            alert('Erro ao finalizar pedido: ' + (error.error || 'Erro desconhecido'));
        }
    } catch (error) {
        console.error('Erro ao finalizar pedido:', error);
        alert('Erro de conexão. Tente novamente.');
    } finally {
        btnFinalizarPedido.textContent = 'Ir para Pagamento';
        btnFinalizarPedido.disabled = false;
    }
}

// Mostrar modal de confirmação
function mostrarModal() {
    modal.classList.add('show');
    modalOverlay.classList.add('show');
}

// Fechar modal
function fecharModal() {
    modal.classList.remove('show');
    modalOverlay.classList.remove('show');
}

// Logout
async function logout() {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/logout`, {
            method: 'POST',
            credentials: 'include'
        });

        if (response.ok) {
            localStorage.removeItem('carrinho');
            // garante que o front saiba que não está logado
            usuarioLogado = null;
            document.getElementById('authButtons').style.display = 'flex';
            document.getElementById('userInfo').style.display = 'none';
            atualizarCarrinho();
            window.location.href = '../auth/login.html';
        }
    } catch (error) {
        console.error('Erro no logout:', error);
        localStorage.removeItem('carrinho');
        usuarioLogado = null;
        window.location.href = '../auth/login.html';
    }
}

// Salvar carrinho no localStorage
function salvarCarrinhoLocalStorage() {
    localStorage.setItem('carrinho', JSON.stringify(carrinho));
}

// Carregar carrinho do localStorage
function carregarCarrinhoLocalStorage() {
    const carrinhoSalvo = localStorage.getItem('carrinho');
    if (carrinhoSalvo) {
        carrinho = JSON.parse(carrinhoSalvo);
        atualizarCarrinho();
    }
}

// Fechar carrinho ao clicar fora
document.addEventListener('click', (e) => {
    if (e.target === cartOverlay) {
        toggleCarrinho();
    }
});

// Fechar modal ao clicar fora
document.addEventListener('click', (e) => {
    if (e.target === modalOverlay) {
        fecharModal();
    }
});
